package com.essa.iptv.ui

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.layout.fillMaxSize
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

private val AppColors = darkColorScheme(
    primary = Color(0xFF7C4DFF),
    surface = Color(0xFF161B22),
    background = Color(0xFF0E1116),
    surfaceVariant = Color(0xFF1F2630)
)

class MainActivity : ComponentActivity() {

    private val notificationsPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            notificationsPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { AppRoot() }
    }
}

@Composable
private fun AppRoot() {
    MaterialTheme(colorScheme = AppColors) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                val navController = rememberNavController()
                NavHost(navController = navController, startDestination = "playlists") {
                    composable("playlists") {
                        PlaylistsScreen(
                            onOpen = { playlistId ->
                                navController.navigate("home/$playlistId")
                            },
                            onDownloads = { navController.navigate("downloads") }
                        )
                    }
                    composable("home/{playlistId}") { entry ->
                        val playlistId =
                            entry.arguments?.getString("playlistId") ?: return@composable
                        HomeScreen(
                            playlistId = playlistId,
                            onOpenSeries = { seriesId ->
                                navController.navigate("series/$playlistId/$seriesId")
                            },
                            onDownloads = { navController.navigate("downloads") },
                            onBack = { navController.popBackStack() }
                        )
                    }
                    composable("series/{playlistId}/{seriesId}") { entry ->
                        val playlistId =
                            entry.arguments?.getString("playlistId") ?: return@composable
                        val seriesId = entry.arguments?.getString("seriesId")
                            ?.toIntOrNull() ?: return@composable
                        SeriesDetailScreen(
                            playlistId = playlistId,
                            seriesId = seriesId,
                            onBack = { navController.popBackStack() },
                            onDownloads = { navController.navigate("downloads") }
                        )
                    }
                    composable("downloads") {
                        DownloadsScreen(onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }
}
