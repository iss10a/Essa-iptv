package com.essa.iptv.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.essa.iptv.AppGraph
import com.essa.iptv.data.LiveChannel
import com.essa.iptv.data.PlaylistEntity
import com.essa.iptv.data.SeriesItem
import com.essa.iptv.data.VodItem
import com.essa.iptv.player.PlayerActivity
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    playlistId: String,
    onOpenSeries: (Int) -> Unit,
    onDownloads: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var playlist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var live by remember { mutableStateOf<List<LiveChannel>>(emptyList()) }
    var movies by remember { mutableStateOf<List<VodItem>>(emptyList()) }
    var series by remember { mutableStateOf<List<SeriesItem>>(emptyList()) }

    LaunchedEffect(playlistId) {
        val loaded = AppGraph.db.playlistDao().byId(playlistId)
        playlist = loaded
        if (loaded == null) {
            error = "القائمة غير موجودة"
            loading = false
            return@LaunchedEffect
        }
        loading = true
        error = null
        try {
            live = AppGraph.repo.liveChannels(loaded)
            movies = AppGraph.repo.vodItems(loaded)
            series = AppGraph.repo.seriesList(loaded)
        } catch (loadError: Exception) {
            error = "تعذّر الاتصال بالسيرفر: ${loadError.message ?: ""}"
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(playlist?.name ?: "") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = onDownloads) {
                        Icon(Icons.Filled.Download, contentDescription = "التنزيلات")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = tab) {
                listOf("مباشر", "أفلام", "مسلسلات").forEachIndexed { index, title ->
                    Tab(
                        selected = tab == index,
                        onClick = { tab = index },
                        text = { Text(title) }
                    )
                }
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("بحث") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
            when {
                loading -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator() }

                error != null -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { Text(error ?: "", color = MaterialTheme.colorScheme.error) }

                else -> {
                    val currentPlaylist = playlist ?: return@Column
                    val search = query.trim()
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        when (tab) {
                            0 -> items(
                                live.filter {
                                    search.isEmpty() || it.name.contains(search, true)
                                },
                                key = { it.id }
                            ) { channel ->
                                MediaRow(
                                    title = channel.name,
                                    image = channel.icon,
                                    onClick = {
                                        PlayerActivity.open(
                                            context,
                                            AppGraph.repo.liveUrl(currentPlaylist, channel.id)
                                        )
                                    }
                                )
                            }

                            1 -> items(
                                movies.filter {
                                    search.isEmpty() || it.name.contains(search, true)
                                },
                                key = { it.id }
                            ) { movie ->
                                MediaRow(
                                    title = movie.name,
                                    image = movie.icon,
                                    onClick = {
                                        PlayerActivity.open(
                                            context,
                                            AppGraph.repo.vodUrl(
                                                currentPlaylist, movie.id, movie.ext
                                            )
                                        )
                                    },
                                    trailing = {
                                        IconButton(onClick = {
                                            scope.launch {
                                                AppGraph.downloader.enqueue(
                                                    playlistId = currentPlaylist.id,
                                                    title = movie.name,
                                                    url = AppGraph.repo.vodUrl(
                                                        currentPlaylist, movie.id, movie.ext
                                                    ),
                                                    contentType = "vod",
                                                    poster = movie.icon
                                                )
                                            }
                                        }) {
                                            Icon(
                                                Icons.Filled.Download,
                                                contentDescription = "تحميل"
                                            )
                                        }
                                    }
                                )
                            }

                            else -> items(
                                series.filter {
                                    search.isEmpty() || it.name.contains(search, true)
                                },
                                key = { it.id }
                            ) { item ->
                                MediaRow(
                                    title = item.name,
                                    image = item.cover,
                                    onClick = { onOpenSeries(item.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MediaRow(
    title: String,
    image: String?,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = image,
            contentDescription = null,
            modifier = Modifier.size(46.dp)
        )
        Text(
            title,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 12.dp),
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 2
        )
        trailing?.invoke()
    }
}
