package com.essa.iptv

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.essa.iptv.data.AppDatabase
import com.essa.iptv.data.XtreamRepository
import com.essa.iptv.download.Downloader

object AppGraph {
    lateinit var db: AppDatabase
        private set
    lateinit var repo: XtreamRepository
        private set
    lateinit var downloader: Downloader
        private set

    fun init(app: Application) {
        db = AppDatabase.build(app)
        repo = XtreamRepository()
        downloader = Downloader(app, db.downloadDao())
    }
}

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(
                DOWNLOAD_CHANNEL_ID,
                "التنزيلات",
                NotificationManager.IMPORTANCE_LOW
            )
        )
    }

    companion object {
        const val DOWNLOAD_CHANNEL_ID = "downloads"
    }
}
