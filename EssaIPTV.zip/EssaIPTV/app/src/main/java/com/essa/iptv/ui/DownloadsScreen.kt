package com.essa.iptv.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TriStateCheckbox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.unit.dp
import com.essa.iptv.AppGraph
import com.essa.iptv.data.DownloadEntity
import com.essa.iptv.data.DownloadStatus
import com.essa.iptv.player.PlayerActivity
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val downloads by AppGraph.db.downloadDao().observeAll()
        .collectAsState(initial = emptyList())
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var confirmDelete by remember { mutableStateOf(false) }

    // Drop selection entries that no longer exist
    val validIds = downloads.map { it.id }.toSet()
    if (selected.any { it !in validIds }) {
        selected = selected.filterTo(mutableSetOf()) { it in validIds }
    }

    val selectedItems = downloads.filter { it.id in selected }
    val allSelected = downloads.isNotEmpty() && selected.size == downloads.size
    val someSelected = selected.isNotEmpty() && !allSelected
    val canPause = selectedItems.any {
        it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.DOWNLOADING
    }
    val canResume = selectedItems.any {
        it.status == DownloadStatus.PAUSED || it.status == DownloadStatus.FAILED
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("التنزيلات") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (downloads.isNotEmpty()) {
                // ===== Bulk actions bar =====
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TriStateCheckbox(
                                state = when {
                                    allSelected -> ToggleableState.On
                                    someSelected -> ToggleableState.Indeterminate
                                    else -> ToggleableState.Off
                                },
                                onClick = {
                                    selected = if (allSelected) emptySet()
                                    else downloads.map { it.id }.toSet()
                                }
                            )
                            Text("تحديد الكل")
                            if (selected.isNotEmpty()) {
                                Text(
                                    "  (${selected.size} محدد)",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                enabled = canPause,
                                onClick = {
                                    scope.launch {
                                        selectedItems.forEach {
                                            AppGraph.downloader.pause(it.id)
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Filled.Pause, contentDescription = null)
                                Text(" إيقاف المحدد")
                            }
                            OutlinedButton(
                                enabled = canResume,
                                onClick = {
                                    scope.launch {
                                        selectedItems.forEach {
                                            AppGraph.downloader.resume(it.id)
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                                Text(" استئناف المحدد")
                            }
                            OutlinedButton(
                                enabled = selected.isNotEmpty(),
                                onClick = { confirmDelete = true }
                            ) {
                                Icon(
                                    Icons.Filled.Delete,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Text(
                                    " حذف المحدد",
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            if (downloads.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { Text("لا توجد تنزيلات بعد") }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(downloads, key = { it.id }) { item ->
                        DownloadRow(
                            item = item,
                            checked = item.id in selected,
                            onCheckedChange = { isChecked ->
                                selected =
                                    if (isChecked) selected + item.id
                                    else selected - item.id
                            },
                            onPlay = {
                                if (item.status == DownloadStatus.COMPLETED) {
                                    PlayerActivity.open(context, item.filePath)
                                }
                            },
                            onPauseResume = {
                                scope.launch {
                                    when (item.status) {
                                        DownloadStatus.QUEUED,
                                        DownloadStatus.DOWNLOADING ->
                                            AppGraph.downloader.pause(item.id)
                                        DownloadStatus.PAUSED,
                                        DownloadStatus.FAILED ->
                                            AppGraph.downloader.resume(item.id)
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف المحدد") },
            text = { Text("هل تريد حذف ${selected.size} عنصرًا من قائمة التنزيلات مع ملفاتها؟") },
            confirmButton = {
                TextButton(onClick = {
                    val ids = selected.toList()
                    confirmDelete = false
                    selected = emptySet()
                    scope.launch { AppGraph.downloader.delete(ids) }
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
private fun DownloadRow(
    item: DownloadEntity,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    onPlay: () -> Unit,
    onPauseResume: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = checked, onCheckedChange = onCheckedChange)
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        item.title,
                        style = MaterialTheme.typography.bodyLarge,
                        maxLines = 2
                    )
                    Text(
                        statusLabel(item),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                when (item.status) {
                    DownloadStatus.QUEUED, DownloadStatus.DOWNLOADING ->
                        IconButton(onClick = onPauseResume) {
                            Icon(Icons.Filled.Pause, contentDescription = "إيقاف")
                        }
                    DownloadStatus.PAUSED, DownloadStatus.FAILED ->
                        IconButton(onClick = onPauseResume) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "استئناف")
                        }
                    DownloadStatus.COMPLETED ->
                        IconButton(onClick = onPlay) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "تشغيل")
                        }
                }
            }
            if (item.status == DownloadStatus.DOWNLOADING ||
                item.status == DownloadStatus.PAUSED
            ) {
                if (item.total > 0) {
                    LinearProgressIndicator(
                        progress = {
                            (item.bytes.toFloat() / item.total).coerceIn(0f, 1f)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                    )
                }
            }
        }
    }
}

private fun statusLabel(item: DownloadEntity): String {
    val megabytes = item.bytes / (1024 * 1024)
    val totalMegabytes = item.total / (1024 * 1024)
    return when (item.status) {
        DownloadStatus.QUEUED -> "في الانتظار"
        DownloadStatus.DOWNLOADING ->
            if (item.total > 0) "جارٍ التحميل — $megabytes / $totalMegabytes م.ب"
            else "جارٍ التحميل — $megabytes م.ب"
        DownloadStatus.PAUSED -> "متوقف — $megabytes م.ب"
        DownloadStatus.COMPLETED -> "مكتمل — $totalMegabytes م.ب"
        DownloadStatus.FAILED -> "فشل: ${item.error ?: ""}"
        else -> item.status
    }
}
