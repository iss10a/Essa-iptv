package com.essa.iptv.download

import android.content.Context
import android.content.Intent
import android.os.Environment
import com.essa.iptv.data.DownloadDao
import com.essa.iptv.data.DownloadEntity
import com.essa.iptv.data.DownloadStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit

/**
 * Sequential download engine with real pause/resume via HTTP Range requests.
 * Partial bytes are kept on pause; resume continues from where it stopped
 * when the server supports ranges, otherwise it restarts from zero.
 */
class Downloader(
    private val context: Context,
    private val dao: DownloadDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var workerJob: Job? = null

    /** ID of the item currently being written, used to interrupt on pause. */
    @Volatile
    private var activeId: Long = -1

    @Volatile
    private var abortActive: Boolean = false

    /** Emits the active download id + progress percent for the notification. */
    val activeProgress = MutableStateFlow<Pair<Long, Int>?>(null)

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)
        .build()

    private fun downloadsDir(): File {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun sanitize(name: String): String =
        name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().take(120)

    suspend fun enqueue(
        playlistId: String,
        title: String,
        url: String,
        contentType: String,
        seriesId: Int? = null,
        season: Int? = null,
        episode: Int? = null,
        poster: String? = null
    ): Boolean {
        val existing = dao.byUrl(url, playlistId)
        if (existing != null &&
            existing.status != DownloadStatus.FAILED
        ) {
            return false
        }
        val ext = url.substringAfterLast('.', "mp4").take(5)
        val file = File(downloadsDir(), sanitize(title) + "." + ext)
        if (existing != null) {
            dao.update(
                existing.copy(
                    status = DownloadStatus.QUEUED,
                    bytes = 0,
                    total = 0,
                    error = null,
                    filePath = file.absolutePath
                )
            )
        } else {
            dao.insert(
                DownloadEntity(
                    playlistId = playlistId,
                    title = title,
                    url = url,
                    filePath = file.absolutePath,
                    status = DownloadStatus.QUEUED,
                    contentType = contentType,
                    seriesId = seriesId,
                    season = season,
                    episode = episode,
                    poster = poster
                )
            )
        }
        kick()
        return true
    }

    fun kick() {
        context.startForegroundService(Intent(context, DownloadService::class.java))
        scope.launch { startWorkerIfIdle() }
    }

    private suspend fun startWorkerIfIdle() = mutex.withLock {
        if (workerJob?.isActive == true) return
        workerJob = scope.launch { workLoop() }
    }

    private suspend fun workLoop() {
        while (scope.isActive) {
            val next = dao.firstWithStatus(DownloadStatus.QUEUED) ?: break
            runOne(next)
        }
        activeProgress.value = null
        context.startService(
            Intent(context, DownloadService::class.java)
                .setAction(DownloadService.ACTION_MAYBE_STOP)
        )
    }

    private suspend fun runOne(item: DownloadEntity) {
        activeId = item.id
        abortActive = false
        dao.setStatus(item.id, DownloadStatus.DOWNLOADING)

        val file = File(item.filePath)
        var startFrom = if (file.exists()) file.length() else 0L

        try {
            val requestBuilder = Request.Builder().url(item.url)
            if (startFrom > 0) {
                requestBuilder.header("Range", "bytes=$startFrom-")
            }
            http.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IllegalStateException("HTTP ${response.code}")
                }
                val isPartial = response.code == 206
                if (!isPartial) {
                    // Server ignored the range request: restart from zero.
                    startFrom = 0
                    file.delete()
                }
                val bodyLength = response.body?.contentLength() ?: -1L
                val total =
                    if (bodyLength > 0) startFrom + bodyLength else item.total

                val body = response.body ?: throw IllegalStateException("Empty body")
                RandomAccessFile(file, "rw").use { output ->
                    output.seek(startFrom)
                    val input = body.byteStream()
                    val buffer = ByteArray(256 * 1024)
                    var written = startFrom
                    var lastDbUpdate = 0L
                    while (true) {
                        if (abortActive) {
                            dao.setProgress(
                                item.id, written, total, DownloadStatus.PAUSED
                            )
                            return
                        }
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        written += read
                        val now = System.currentTimeMillis()
                        if (now - lastDbUpdate > 500) {
                            lastDbUpdate = now
                            dao.setProgress(
                                item.id, written, total, DownloadStatus.DOWNLOADING
                            )
                            val percent =
                                if (total > 0) ((written * 100) / total).toInt() else 0
                            activeProgress.value = item.id to percent
                        }
                    }
                    dao.setProgress(item.id, written, written, DownloadStatus.COMPLETED)
                }
            }
        } catch (error: Exception) {
            if (abortActive) {
                val bytes = if (file.exists()) file.length() else 0
                dao.setProgress(item.id, bytes, item.total, DownloadStatus.PAUSED)
            } else {
                dao.setStatus(
                    item.id, DownloadStatus.FAILED, error.message ?: "خطأ غير معروف"
                )
            }
        } finally {
            activeId = -1
        }
    }

    suspend fun pause(id: Long) {
        val item = dao.byId(id) ?: return
        when (item.status) {
            DownloadStatus.DOWNLOADING -> {
                if (activeId == id) abortActive = true
                else dao.setStatus(id, DownloadStatus.PAUSED)
            }
            DownloadStatus.QUEUED -> dao.setStatus(id, DownloadStatus.PAUSED)
        }
    }

    suspend fun resume(id: Long) {
        val item = dao.byId(id) ?: return
        if (item.status == DownloadStatus.PAUSED || item.status == DownloadStatus.FAILED) {
            dao.setStatus(id, DownloadStatus.QUEUED)
            kick()
        }
    }

    suspend fun delete(ids: List<Long>) {
        if (ids.isEmpty()) return
        if (activeId in ids) abortActive = true
        val items = dao.byIds(ids)
        for (item in items) {
            runCatching { File(item.filePath).delete() }
        }
        dao.deleteByIds(ids)
    }
}
