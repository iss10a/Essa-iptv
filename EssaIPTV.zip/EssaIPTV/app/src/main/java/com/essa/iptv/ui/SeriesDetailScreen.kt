package com.essa.iptv.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Downloading
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.essa.iptv.AppGraph
import com.essa.iptv.data.PlaylistEntity
import com.essa.iptv.data.SeriesInfo
import com.essa.iptv.player.PlayerActivity
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesDetailScreen(
    playlistId: String,
    seriesId: Int,
    onBack: () -> Unit,
    onDownloads: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var playlist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var info by remember { mutableStateOf<SeriesInfo?>(null) }
    var selectedSeason by remember { mutableStateOf<Int?>(null) }
    var downloadingSeason by remember { mutableStateOf<Int?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(playlistId, seriesId) {
        val loaded = AppGraph.db.playlistDao().byId(playlistId)
        playlist = loaded
        if (loaded == null) {
            error = "القائمة غير موجودة"
            loading = false
            return@LaunchedEffect
        }
        try {
            val seriesInfo = AppGraph.repo.seriesInfo(loaded, seriesId)
            info = seriesInfo
            selectedSeason = seriesInfo.seasons.keys.firstOrNull()
        } catch (loadError: Exception) {
            error = "تعذّر تحميل المسلسل: ${loadError.message ?: ""}"
        } finally {
            loading = false
        }
    }

    fun downloadSeason(seasonNumber: Int) {
        val currentPlaylist = playlist ?: return
        val seriesInfo = info ?: return
        val episodes = seriesInfo.seasons[seasonNumber] ?: return
        if (downloadingSeason != null) return
        downloadingSeason = seasonNumber
        scope.launch {
            var added = 0
            for (episode in episodes) {
                val label = "S%02dE%02d".format(episode.season, episode.num)
                val added1 = AppGraph.downloader.enqueue(
                    playlistId = currentPlaylist.id,
                    title = "${seriesInfo.name} - $label - ${episode.title}",
                    url = AppGraph.repo.episodeUrl(
                        currentPlaylist, episode.id, episode.ext
                    ),
                    contentType = "episode",
                    seriesId = seriesId,
                    season = episode.season,
                    episode = episode.num,
                    poster = episode.image ?: seriesInfo.cover
                )
                if (added1) added++
            }
            downloadingSeason = null
            snackbar.showSnackbar(
                "تمت إضافة $added حلقة من الموسم $seasonNumber إلى التنزيلات"
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(info?.name ?: "") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = onDownloads) {
                        Icon(Icons.Filled.Download, contentDescription = "التنزيلات")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        when {
            loading -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }

            error != null -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) { Text(error ?: "", color = MaterialTheme.colorScheme.error) }

            else -> {
                val seriesInfo = info ?: return@Scaffold
                val currentPlaylist = playlist ?: return@Scaffold
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {
                    // Season selector chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        seriesInfo.seasons.keys.forEach { seasonNumber ->
                            FilterChip(
                                selected = selectedSeason == seasonNumber,
                                onClick = { selectedSeason = seasonNumber },
                                label = { Text("الموسم $seasonNumber") }
                            )
                        }
                    }

                    // ===== Download-whole-season buttons (one per season) =====
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        seriesInfo.seasons.keys.forEach { seasonNumber ->
                            AssistChip(
                                onClick = { downloadSeason(seasonNumber) },
                                enabled = downloadingSeason == null,
                                label = { Text("تحميل الموسم $seasonNumber") },
                                leadingIcon = {
                                    Icon(
                                        if (downloadingSeason == seasonNumber)
                                            Icons.Filled.Downloading
                                        else Icons.Filled.Download,
                                        contentDescription = null
                                    )
                                }
                            )
                        }
                    }

                    val episodes =
                        selectedSeason?.let { seriesInfo.seasons[it] } ?: emptyList()
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(episodes, key = { it.id }) { episode ->
                            MediaRow(
                                title = "حلقة ${episode.num} — ${episode.title}",
                                image = episode.image ?: seriesInfo.cover,
                                onClick = {
                                    PlayerActivity.open(
                                        context,
                                        AppGraph.repo.episodeUrl(
                                            currentPlaylist, episode.id, episode.ext
                                        )
                                    )
                                },
                                trailing = {
                                    IconButton(onClick = {
                                        scope.launch {
                                            val label = "S%02dE%02d"
                                                .format(episode.season, episode.num)
                                            AppGraph.downloader.enqueue(
                                                playlistId = currentPlaylist.id,
                                                title = "${seriesInfo.name} - $label - ${episode.title}",
                                                url = AppGraph.repo.episodeUrl(
                                                    currentPlaylist,
                                                    episode.id,
                                                    episode.ext
                                                ),
                                                contentType = "episode",
                                                seriesId = seriesId,
                                                season = episode.season,
                                                episode = episode.num,
                                                poster = episode.image ?: seriesInfo.cover
                                            )
                                        }
                                    }) {
                                        Icon(
                                            Icons.Filled.Download,
                                            contentDescription = "تحميل الحلقة"
                                        )
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
