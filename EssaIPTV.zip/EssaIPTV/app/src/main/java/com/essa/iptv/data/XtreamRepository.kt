package com.essa.iptv.data

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient

data class LiveChannel(val id: Int, val name: String, val icon: String?)
data class VodItem(val id: Int, val name: String, val icon: String?, val ext: String)
data class SeriesItem(val id: Int, val name: String, val cover: String?)
data class Episode(
    val id: String,
    val title: String,
    val season: Int,
    val num: Int,
    val ext: String,
    val image: String?
)
data class SeriesInfo(
    val name: String,
    val plot: String?,
    val cover: String?,
    val seasons: Map<Int, List<Episode>>
)

interface XtreamApi {
    @GET("player_api.php")
    suspend fun call(
        @Query("username") username: String,
        @Query("password") password: String,
        @Query("action") action: String? = null,
        @Query("series_id") seriesId: Int? = null
    ): JsonElement
}

class XtreamRepository {

    private val apis = ConcurrentHashMap<String, XtreamApi>()

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun normalizeBase(serverUrl: String): String {
        var base = serverUrl.trim()
        if (!base.startsWith("http://") && !base.startsWith("https://")) {
            base = "http://$base"
        }
        return base.trimEnd('/')
    }

    private fun api(playlist: PlaylistEntity): XtreamApi {
        val base = normalizeBase(playlist.serverUrl)
        return apis.getOrPut(base) {
            Retrofit.Builder()
                .baseUrl("$base/")
                .client(http)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(XtreamApi::class.java)
        }
    }

    private fun JsonObject.str(key: String): String? =
        if (has(key) && !get(key).isJsonNull) get(key).asString else null

    private fun JsonObject.int(key: String): Int? =
        str(key)?.toDoubleOrNull()?.toInt()

    suspend fun liveChannels(playlist: PlaylistEntity): List<LiveChannel> =
        api(playlist).call(playlist.username, playlist.password, "get_live_streams")
            .asJsonArray.mapNotNull { element ->
                val obj = element.asJsonObject
                val id = obj.int("stream_id") ?: return@mapNotNull null
                LiveChannel(id, obj.str("name") ?: "بدون اسم", obj.str("stream_icon"))
            }

    suspend fun vodItems(playlist: PlaylistEntity): List<VodItem> =
        api(playlist).call(playlist.username, playlist.password, "get_vod_streams")
            .asJsonArray.mapNotNull { element ->
                val obj = element.asJsonObject
                val id = obj.int("stream_id") ?: return@mapNotNull null
                VodItem(
                    id,
                    obj.str("name") ?: "بدون اسم",
                    obj.str("stream_icon"),
                    obj.str("container_extension") ?: "mp4"
                )
            }

    suspend fun seriesList(playlist: PlaylistEntity): List<SeriesItem> =
        api(playlist).call(playlist.username, playlist.password, "get_series")
            .asJsonArray.mapNotNull { element ->
                val obj = element.asJsonObject
                val id = obj.int("series_id") ?: return@mapNotNull null
                SeriesItem(id, obj.str("name") ?: "بدون اسم", obj.str("cover"))
            }

    suspend fun seriesInfo(playlist: PlaylistEntity, seriesId: Int): SeriesInfo {
        val root = api(playlist)
            .call(playlist.username, playlist.password, "get_series_info", seriesId)
            .asJsonObject
        val info = root.getAsJsonObject("info")
        val seasons = sortedMapOf<Int, List<Episode>>()
        val episodesElement = root.get("episodes")
        if (episodesElement != null && episodesElement.isJsonObject) {
            for ((seasonKey, seasonValue) in episodesElement.asJsonObject.entrySet()) {
                val seasonNum = seasonKey.toIntOrNull() ?: continue
                if (!seasonValue.isJsonArray) continue
                val episodes = seasonValue.asJsonArray.mapNotNull { episodeElement ->
                    val obj = episodeElement.asJsonObject
                    val id = obj.str("id") ?: return@mapNotNull null
                    val episodeInfo =
                        if (obj.has("info") && obj.get("info").isJsonObject)
                            obj.getAsJsonObject("info")
                        else null
                    Episode(
                        id = id,
                        title = obj.str("title") ?: "حلقة",
                        season = obj.int("season") ?: seasonNum,
                        num = obj.int("episode_num") ?: 0,
                        ext = obj.str("container_extension") ?: "mp4",
                        image = episodeInfo?.str("movie_image")
                    )
                }.sortedBy { it.num }
                seasons[seasonNum] = episodes
            }
        }
        return SeriesInfo(
            name = info?.str("name") ?: "",
            plot = info?.str("plot"),
            cover = info?.str("cover"),
            seasons = seasons
        )
    }

    fun liveUrl(playlist: PlaylistEntity, streamId: Int): String {
        val base = normalizeBase(playlist.serverUrl)
        return "$base/live/${playlist.username}/${playlist.password}/$streamId.m3u8"
    }

    fun vodUrl(playlist: PlaylistEntity, streamId: Int, ext: String): String {
        val base = normalizeBase(playlist.serverUrl)
        return "$base/movie/${playlist.username}/${playlist.password}/$streamId.$ext"
    }

    fun episodeUrl(playlist: PlaylistEntity, episodeId: String, ext: String): String {
        val base = normalizeBase(playlist.serverUrl)
        return "$base/series/${playlist.username}/${playlist.password}/$episodeId.$ext"
    }
}
